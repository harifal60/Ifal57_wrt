package com.ifal57wrt.stb;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.*;
import android.widget.Toast;

public class MainActivity extends Activity {
 private static final String HOME="https://ifal57wrt.up.railway.app/";
 private WebView web;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state); web=new WebView(this); setContentView(web);
  WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setSupportZoom(false);
  web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
  web.setDownloadListener((url,ua,disposition,mime,size)->{
   try {
    DownloadManager.Request req=new DownloadManager.Request(Uri.parse(url));
    req.setTitle("Download APK IFAL57_WRT"); req.setDescription("Mengunduh aplikasi dari katalog IFAL57_WRT");
    req.setMimeType("application/vnd.android.package-archive");
    req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
    req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, apkName(disposition));
    ((DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(req);
    Toast.makeText(this,"Download dimulai. Buka notifikasi setelah selesai untuk memasang APK.",Toast.LENGTH_LONG).show();
   } catch(Exception e) { Toast.makeText(this,"Gagal download: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
  });
  if(state==null) web.loadUrl(HOME); else web.restoreState(state);
 }
 private String apkName(String d) {
  if(d!=null && d.contains("filename=")) {
   String n=d.substring(d.indexOf("filename=")+9).replace("\"","").trim();
   if(n.toLowerCase().endsWith(".apk")) return n.replaceAll("[^A-Za-z0-9._-]","_");
  }
  return "IFAL57_WRT.apk";
 }
 @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);if(web!=null)web.saveState(out);}
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
