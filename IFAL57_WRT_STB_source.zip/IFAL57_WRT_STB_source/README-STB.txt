IFAL57_WRT Android TV / STB - versi awal

Fitur:
- Membuka katalog online IFAL57_WRT.
- Navigasi halaman memakai remote STB.
- Tombol Unduh APK menggunakan Download Manager Android.
- Setelah selesai, buka notifikasi Download untuk memasang APK.
- Android tetap meminta izin Install unknown apps dan konfirmasi pengguna.

Cara build:
1. Ekstrak ZIP ini.
2. Upload semua isi folder ke root repository harifal60/Ifal57_wrt (bukan folder pembungkusnya).
3. Pastikan folder .github/workflows ikut ter-upload.
4. Buka GitHub repository > Actions.
5. Pilih Build IFAL57_WRT STB APK > Run workflow.
6. Setelah berhasil, buka run > Artifacts > IFAL57_WRT-STB-APK.
7. Unduh ZIP artifact, ekstrak, lalu ambil app-debug.apk.

Catatan: Versi awal ini memerlukan internet. Instalasi APK memerlukan persetujuan pengguna Android.

- Pemeriksaan update aplikasi berjalan di latar belakang setiap sekitar 15 menit saat jaringan tersedia (jadwal Android dapat menyesuaikan kondisi perangkat).
- Notifikasi update memerlukan izin notifikasi. Pemeriksaan pertama hanya menyimpan versi katalog sebagai acuan; notifikasi dikirim saat versi berubah setelahnya.
