package com.ifal57wrt.stb;

import android.app.DownloadManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;

public class ApkDownloadReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "ifal57wrt_apk_downloads";
    private static final String ACTION_INSTALL_APK = "com.ifal57wrt.stb.INSTALL_APK";
    private static final String EXTRA_DOWNLOAD_ID = "download_id";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(intent.getAction())) return;
        long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
        if (id < 0) return;

        DownloadManager dm = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Query query = new DownloadManager.Query().setFilterById(id);
        Cursor cursor = dm.query(query);
        boolean success = false;
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    int statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
                    success = statusIndex >= 0 && cursor.getInt(statusIndex) == DownloadManager.STATUS_SUCCESSFUL;
                }
            } finally {
                cursor.close();
            }
        }
        if (!success || dm.getUriForDownloadedFile(id) == null) return;

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Download APK IFAL57_WRT", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Notifikasi APK yang sudah selesai diunduh");
            manager.createNotificationChannel(channel);
        }

        Intent openInstaller = new Intent(context, MainActivity.class);
        openInstaller.setAction(ACTION_INSTALL_APK);
        openInstaller.putExtra(EXTRA_DOWNLOAD_ID, id);
        openInstaller.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(context, (int) id, openInstaller,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        Notification notification = builder
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("APK selesai diunduh")
                .setContentText("Ketuk untuk memasang aplikasi sekarang")
                .setContentIntent(pending)
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .build();
        manager.notify((int) id, notification);
    }
}
