package com.ifal57wrt.stb;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String HOME = "https://ifal57wrt.up.railway.app/";
    private static final int FILE_CHOOSER_REQUEST = 100;
    private static final int INSTALL_PERMISSION_REQUEST = 200;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 201;
    private static final String ACTION_INSTALL_APK = "com.ifal57wrt.stb.INSTALL_APK";
    private static final String EXTRA_DOWNLOAD_ID = "download_id";

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private long pendingInstallId = -1;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(false);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(intent, "Pilih File APK"), FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.setDownloadListener((url, ua, disposition, mime, size) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                String namaFile = apkName(disposition, url);
                req.setTitle(namaFile);
                req.setDescription("Mengunduh aplikasi dari katalog IFAL57_WRT");
                req.setMimeType("application/vnd.android.package-archive");
                // Notifikasi bawaan disembunyikan; notifikasi Instal sekarang dibuat oleh ApkDownloadReceiver.
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
                if (ua != null && !ua.isEmpty()) req.addRequestHeader("User-Agent", ua);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, namaFile);
                long id = ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(req);
                Toast.makeText(this, "Download dimulai", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Gagal download: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        if (state == null) web.loadUrl(HOME); else web.restoreState(state);
        askNotificationPermissionIfNeeded();
        handleInstallIntent(getIntent());
    }

    private void askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleInstallIntent(intent);
    }

    private void handleInstallIntent(Intent intent) {
        if (intent != null && ACTION_INSTALL_APK.equals(intent.getAction())) {
            long id = intent.getLongExtra(EXTRA_DOWNLOAD_ID, -1);
            if (id >= 0) installDownloadedApk(id);
        }
    }

    private void installDownloadedApk(long downloadId) {
        DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        Uri apkUri = dm.getUriForDownloadedFile(downloadId);
        if (apkUri == null) {
            Toast.makeText(this, "File APK belum siap atau download gagal", Toast.LENGTH_LONG).show();
            return;
        }

        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            pendingInstallId = downloadId;
            Intent settingsIntent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(settingsIntent, INSTALL_PERMISSION_REQUEST);
            Toast.makeText(this, "Izinkan IFAL57_WRT memasang aplikasi, lalu kembali", Toast.LENGTH_LONG).show();
            return;
        }

        try {
            Intent install = new Intent(Intent.ACTION_VIEW);
            install.setDataAndType(apkUri, "application/vnd.android.package-archive");
            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(install);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak bisa membuka installer: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else if (requestCode == INSTALL_PERMISSION_REQUEST) {
            long id = pendingInstallId;
            pendingInstallId = -1;
            if (id >= 0 && Build.VERSION.SDK_INT >= 26 && getPackageManager().canRequestPackageInstalls()) {
                installDownloadedApk(id);
            } else {
                Toast.makeText(this, "Izin instalasi belum diaktifkan. Ketuk notifikasi lagi setelah mengizinkan.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private String apkName(String disposition, String url) {
        String nama = "";
        if (disposition != null && disposition.contains("filename=")) {
            nama = disposition.substring(disposition.indexOf("filename=") + 9)
                    .replace("\"", "").trim();
        }
        if (nama.isEmpty() && url != null) {
            Uri uri = Uri.parse(url);
            nama = uri.getLastPathSegment();
            if (nama == null) nama = "";
        }
        nama = Uri.decode(nama);
        if (!nama.toLowerCase().endsWith(".apk")) nama = "Aplikasi.apk";
        return nama.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
