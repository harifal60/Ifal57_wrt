package com.ifal57wrt.stb;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.*;
import android.widget.Toast;

public class MainActivity extends Activity {
 private static final String HOME="https://ifal57wrt.up.railway.app/";
 private WebView web;
private ValueCallback<Uri[]> filePathCallback;
private static final int FILE_CHOOSER_REQUEST = 100;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state); web=new WebView(this); setContentView(web);
  WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setSupportZoom(false);
  web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient() {
    @Override
    public boolean onShowFileChooser(
            WebView view,
            ValueCallback<Uri[]> callback,
            FileChooserParams params) {

        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
        }

        filePathCallback = callback;

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");

        try {
            startActivityForResult(
                Intent.createChooser(intent, "Pilih File APK"),
                FILE_CHOOSER_REQUEST
            );
        } catch (Exception e) {
            filePathCallback = null;
            return false;
        }

        return true;
    }
});
  web.setDownloadListener((url,ua,disposition,mime,size)->{
   try {
    DownloadManager.Request req=new DownloadManager.Request(Uri.parse(url));
    req.setTitle(namaFile); req.setDescription("Mengunduh aplikasi dari katalog IFAL57_WRT");
    req.setMimeType("application/vnd.android.package-archive");
    req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
    String namaFile = apkName(disposition, url);
req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, namaFile);
req.setTitle(namaFile);
    ((DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(req);
    Toast.makeText(this,"Download dimulai. Buka notifikasi setelah selesai untuk memasang APK.",Toast.LENGTH_LONG).show();
   } catch(Exception e) { Toast.makeText(this,"Gagal download: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
  });
  if(state==null) web.loadUrl(HOME); else web.restoreState(state);
 }
@Override
protected void onActivityResult(
        int requestCode,
        int resultCode,
        Intent data) {

    super.onActivityResult(requestCode, resultCode, data);

    if (requestCode == FILE_CHOOSER_REQUEST) {
        if (filePathCallback == null) return;

        Uri[] results = null;

        if (resultCode == RESULT_OK && data != null
                && data.getData() != null) {
            results = new Uri[]{data.getData()};
        }

        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }
}
 
private String apkName(String d, String url) {
    String nama = "";

    if (d != null && d.contains("filename=")) {
        nama = d.substring(d.indexOf("filename=") + 9)
                .replace("\"", "").trim();
    }

    if (nama.isEmpty() && url != null) {
        Uri uri = Uri.parse(url);
        nama = uri.getLastPathSegment();
        if (nama == null) nama = "";
    }

    nama = Uri.decode(nama);

    if (!nama.toLowerCase().endsWith(".apk")) {
        nama = "Aplikasi.apk";
    }

    return nama.replaceAll("[^a-zA-Z0-9._-]", "_");
}

 @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);if(web!=null)web.saveState(out);}
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
