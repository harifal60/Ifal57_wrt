package com.ifal57wrt.stb;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class AppUpdateWorker extends Worker {
    private static final String CATALOG_URL = "https://ifal57wrt.up.railway.app/api/apps";
    private static final String PREFS = "ifal57_update_check";
    private static final String VERSIONS_KEY = "known_versions";
    private static final String CHANNEL_ID = "app_updates";

    public AppUpdateWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }

    @NonNull @Override public Result doWork() {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(CATALOG_URL).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(12000);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "application/json");
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) return Result.retry();

            StringBuilder body = new StringBuilder();
            try (InputStream input = connection.getInputStream();
                 BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                String line; while ((line = reader.readLine()) != null) body.append(line);
            }
            JSONArray apps = new JSONArray(body.toString());
            SharedPreferences prefs = getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String previousJson = prefs.getString(VERSIONS_KEY, null);
            JSONObject previous = previousJson == null ? null : new JSONObject(previousJson);
            JSONObject current = new JSONObject();
            StringBuilder changedNames = new StringBuilder();
            int changedCount = 0;

            for (int i = 0; i < apps.length(); i++) {
                JSONObject item = apps.optJSONObject(i);
                if (item == null) continue;
                String id = item.optString("id", "");
                String name = item.optString("name", "Aplikasi");
                String version = item.optString("version", "");
                if (id.isEmpty() || version.isEmpty()) continue;
                current.put(id, version);
                if (previous != null && previous.has(id) && !previous.optString(id, "").equals(version)) {
                    changedCount++;
                    if (changedCount <= 3) {
                        if (changedNames.length() > 0) changedNames.append(", ");
                        changedNames.append(name).append(" (").append(version).append(")");
                    }
                }
            }
            // Pemeriksaan pertama menyimpan versi awal tanpa notifikasi massal.
            prefs.edit().putString(VERSIONS_KEY, current.toString()).apply();
            if (previous != null && changedCount > 0) showNotification(changedCount, changedNames.toString());
            return Result.success();
        } catch (Exception error) {
            return Result.retry();
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void showNotification(int count, String names) {
        Context context = getApplicationContext();
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Pembaruan aplikasi", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Pemberitahuan saat aplikasi katalog mendapat versi baru.");
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending = PendingIntent.getActivity(context, 57, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        String title = count == 1 ? "Aplikasi mendapat update" : count + " aplikasi mendapat update";
        String message = names.isEmpty() ? "Buka 57 Store untuk melihat versi terbaru." :
                names + (count > 3 ? " dan " + (count - 3) + " lainnya" : "");
        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title).setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true)
                .setContentIntent(pending).build();
        manager.notify(5701, notification);
    }
}
